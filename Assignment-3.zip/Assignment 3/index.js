const http = require('http');
const fs = require('fs');
let port = 5000;
http.createServer( (req, res) =>{
  //Open a file on the server and return its content:
  fs.readFile('index.html', (err, data) => {
    if(err) throw err;
    console.log(`server started at port ${port}....`);
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(data);
    res.end();
  });
}).listen(`${port}`);